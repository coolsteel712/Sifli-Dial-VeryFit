
/*
*now_time:2026-10-13 06:57:25
*author: vortexwatch
*ftl_version: 010000
*deviceId: DR03
*/
// FTL_VERSION_NUM: 010000
#define WF_RES_IN_FS_SIMU "wf_sifliTest"
#define WF_RES_BUILD_IN_HEADER "wf_sifliTest_header.h"
#include "app_module.h"
#include "lvgl.h"
#include "service_comm.h"
#include "rtdef.h"
#include "app_clock_comm.h"
#include "mod_installer.h"
#include "app_activity_info.h"
#include "app_unit.h"
#include "app_dial_data.h"
// 用于区分特殊格式,目前暂无特殊格式
typedef enum
{
DATA_TYPE_NORMAL, // 正常显示
} DATA_SHOW_TYPE;
typedef struct
{
lv_coord_t x;
lv_coord_t y;
lv_coord_t w;
lv_coord_t h;
uint16_t icon_num_space;
uint16_t num_unit_space;
uint8_t align; // 0:左对齐 1:居中 2:右对齐
} data_area_t; // 存储组件的显示区域信息
typedef struct
{
uint8_t empty; // 空闲变量
} last_data_t;
typedef struct
{
lv_obj_t* time_clock_0_hour;
lv_obj_t* time_clock_0_min;
lv_obj_t* time_clock_0_sec;
lv_obj_t* bg;
data_area_t data_area;
lv_task_t *redraw_task;
app_clock_time_t last_redraw_time;
} clock_sifliTest_t;
#define MODULE_USER_DATA_TYPE clock_sifliTest_t
MODULE_CONTEXT_DEFINE;
//static clock_wicked_t *p_clk_sifliTest = NULL;
#define p_clk_sifliTest MODULE_CONTEXT
// 此处初始值需要为该数据不可能的一个值
static last_data_t last_data;
static last_data_t last_data_template;
static void last_data_template_init()
{
last_data_template.empty = 0;
last_data = last_data_template;
};
static const void *img_time_0_dialPointer_src[] =
{
APP_GET_IMG(time_0_dialPointer_0),
APP_GET_IMG(time_0_dialPointer_1),
APP_GET_IMG(time_0_dialPointer_2),
};
/*
水平对齐函数：支持左中右对齐。
obj_icon: icon的地址，没有填NULL。
obj_digat: 数字obj数组的地址或内部字库label的地址。
obj_num: 数字obj的个数，内部字库填1。
obj_unit: 单位obj的地址，没有填NULL。
area: 数据显示区域数据的地址。
*/
static void watchface_data_align_hor(lv_obj_t *obj_icon,lv_obj_t **obj_digat, uint8_t obj_num, lv_obj_t *obj_unit,data_area_t *area)
{
uint8_t num_len = 0;
uint16_t value_index = 0;
uint16_t obj_width = 0;
// 计算没有隐藏的元素个数
uint8_t num_show = 0;
for(uint8_t i = 0; i < obj_num; i++)
{
if(!lv_obj_get_hidden(obj_digat[i]))
{
num_show++;
}
else
{
break;
}
}
if(obj_icon != NULL)
{
obj_width = lv_obj_get_width(obj_icon);
obj_width += area->icon_num_space;
}
for (uint8_t i = 0; i < num_show; i++)
{
obj_width += lv_obj_get_width(obj_digat[i]);
}
if(obj_unit != NULL)
{
obj_width += lv_obj_get_width(obj_unit);
obj_width += area->num_unit_space;
}
uint8_t idx = 0;
bool is_icon = (obj_icon != NULL);
if(area->align == 0) // 左对齐
{
if(is_icon)
{
lv_obj_align(obj_icon, NULL, LV_ALIGN_IN_TOP_LEFT, area->x, area->y);
}
else
{
lv_obj_align(obj_digat[0], NULL, LV_ALIGN_IN_TOP_LEFT, area->x, area->y);
}
}
else if(area->align == 1) // 居中对齐
{
if(is_icon)
{
lv_obj_align(obj_icon, NULL, LV_ALIGN_IN_TOP_LEFT, area->x + (area->w - obj_width) / 2, area->y);
}
else
{
lv_obj_align(obj_digat[0], NULL, LV_ALIGN_IN_TOP_LEFT, area->x + (area->w - obj_width) / 2, area->y);
}
}
else // 右对齐
{
if(is_icon)
{
lv_obj_align(obj_icon, NULL, LV_ALIGN_IN_TOP_LEFT, area->x + area->w - obj_width, area->y);
}
else
{
lv_obj_align(obj_digat[0], NULL, LV_ALIGN_IN_TOP_LEFT, area->x + area->w - obj_width, area->y);
}
}
if (is_icon)
{
for(idx = 0; idx < num_show; idx++)
{
if(idx == 0)
{
lv_obj_align(obj_digat[0], obj_icon, LV_ALIGN_OUT_RIGHT_MID, area->icon_num_space, 0);
}
else
{
lv_obj_realign(obj_digat[idx]);
}
}
}
else
{
for(idx = 1; idx < num_show; idx++)
{
lv_obj_realign(obj_digat[idx]);
}
}
if(obj_unit != NULL) // 单位跟随最后一个显示的数字
{
lv_obj_align(obj_unit, obj_digat[idx - 1], LV_ALIGN_OUT_RIGHT_MID, area->num_unit_space, 0);
}
}
/* 数据刷新函数：不改变位置，支持内部字库
data_type ： 数据类型，主要用于区分需要特殊处理的，目前暂无需要特别处理的
obj_digat ： obj数组，用于显示数字的obj数组首地址或内部字库的地址
obj_num ： 数组长度，内部字库填1
str_num ： 要显示的字符串
img_list ： 图片数组，数组为NULL时，认为是内部字库
注意：新增符号时，同一个符号，序号必须一致
*/
static void watchface_data_updata(DATA_SHOW_TYPE data_type,lv_obj_t **obj_digat, uint8_t obj_num, char *str_num,const void **img_list)
{
int value_index = 0;
for(int i = 0; i < obj_num; i++)
{
lv_obj_set_hidden(obj_digat[i], true);
}
if(img_list == NULL) // 内部字库
{
lv_label_set_text(obj_digat[0],str_num);
lv_obj_set_hidden(obj_digat[0], false);
return;
}
if(data_type == DATA_TYPE_NORMAL)
{
for (uint8_t i = 0; i < strlen(str_num); i++)
{
if (str_num[i] == '-' || str_num[i] == '/' || str_num[i] == '.' || str_num[i] == 'h') // 这里的字符需要考虑各个数据格式
{
value_index = 10;
}
else if (str_num[i] == 'm' || str_num[i] == ':')
{
value_index = 11;
}
else
{
value_index = str_num[i] - '0';
}
if (value_index < 0 || value_index > 11)
{
value_index = 0;
}
lv_img_set_src(obj_digat[i], img_list[value_index]);
lv_obj_set_hidden(obj_digat[i], false);
}
}
}
static void time_clock_0_update()
{
time_data_t *current_time = service_get_current_time(false);
current_time->hour = hour_format_switch(current_time->hour);
uint16_t hour_angle = (current_time->hour * 300) + (current_time->min * 5);
uint16_t minute_angle = (current_time->min * 60) + current_time->second;
uint16_t sec_angle = (current_time->second * 60) + (current_time->ms * 360 * 10 / 60000);
{
lv_img_set_angle(p_clk_sifliTest->time_clock_0_hour, hour_angle);
lv_img_set_angle(p_clk_sifliTest->time_clock_0_min, minute_angle);
lv_img_set_angle(p_clk_sifliTest->time_clock_0_sec, sec_angle);
}
}
static void clock_page_refresh(lv_task_t *task)
{
time_clock_0_update();
}
/* code for time type:clock */
static void time_clock_0_create(lv_obj_t* parent)
{
lv_obj_t *obj_hour = lv_img_create(parent,NULL);
lv_img_set_src(obj_hour, APP_GET_IMG(time_0_dialPointer_1));
lv_obj_align(obj_hour, NULL, LV_ALIGN_IN_TOP_LEFT, 0+(180-(9)), 0+(180-(74)));
lv_img_set_pivot(obj_hour, 9,74);
p_clk_sifliTest->time_clock_0_hour = obj_hour;
lv_obj_t *obj_min = lv_img_create(parent,NULL);
lv_img_set_src(obj_min, APP_GET_IMG(time_0_dialPointer_2));
lv_obj_align(obj_min, NULL, LV_ALIGN_IN_TOP_LEFT, 0+(180-(9)), 0+(180-(90)));
lv_img_set_pivot(obj_min, 9,90);
p_clk_sifliTest->time_clock_0_min = obj_min;
lv_obj_t *obj_sec = lv_img_create(parent,NULL);
lv_img_set_src(obj_sec, APP_GET_IMG(time_0_dialPointer_3));
lv_obj_align(obj_sec, NULL, LV_ALIGN_IN_TOP_LEFT, 0+(180-(17)), 0+(180-(117)));
lv_img_set_pivot(obj_sec, 17,117);
p_clk_sifliTest->time_clock_0_sec = obj_sec;
}
/* code end */
static rt_int32_t on_init(void *param)
{
MODULE_CONTEXT_ALLOC();
memset(p_clk_sifliTest, 0, sizeof(clock_sifliTest_t));
p_clk_sifliTest->bg = CLOCK_GET_NODE_PARENT;
last_data_template_init();
lv_page_set_scrllable_fit4(p_clk_sifliTest->bg, LV_FIT_NONE, LV_FIT_NONE, LV_FIT_NONE, LV_FIT_NONE);
lv_obj_t *background = lv_img_create(p_clk_sifliTest->bg, NULL);
lv_img_set_src(background, APP_GET_IMG(picture_dialBg_0));
lv_obj_set_style_local_image_opa(background, LV_OBJ_PART_MAIN, LV_STATE_DEFAULT, 255);
lv_obj_align(background, NULL, LV_ALIGN_IN_TOP_LEFT, 0, 0);
lv_page_glue_obj(background, true);
lv_obj_set_parent_event(background, true);
time_clock_0_create(p_clk_sifliTest->bg);
clock_page_refresh(NULL);
return RT_EOK;
}
static rt_int32_t on_pause(void *param)
{
if (p_clk_sifliTest->redraw_task)
{
lv_task_set_prio(p_clk_sifliTest->redraw_task, LV_TASK_PRIO_OFF);
}
return RT_EOK;
}
static rt_int32_t on_resume(void *param)
{
last_data = last_data_template;
if (NULL == p_clk_sifliTest->redraw_task)
{
p_clk_sifliTest->redraw_task = lv_task_create(clock_page_refresh, 200, LV_TASK_PRIO_MID, (void *)0);
}
else
{
lv_task_set_prio(p_clk_sifliTest->redraw_task, LV_TASK_PRIO_MID);
}
clock_page_refresh(NULL); // 初始化创建组价完成后，给所有组件更新一次值。
return RT_EOK;
}
static rt_int32_t on_deinit(void *param)
{
if (p_clk_sifliTest->redraw_task)
{
lv_task_del(p_clk_sifliTest->redraw_task);
p_clk_sifliTest->redraw_task = NULL;
}
if (p_clk_sifliTest)
{
MODULE_CONTEXT_FREE();
}
return RT_EOK;
}
static const app_clock_ops_t ops =
{
.init = on_init,
.pause = on_pause,
.resume = on_resume,
.deinit = on_deinit,
};
void wf_sifliTest_register(void)
{
app_clock_register("wf_sifliTest", app_get_str(key_clk_sifliTest, "sifliTest"), \
&ops, NULL);
}
//only for simulator use
APP_BUILTIN_CLOCK_REGISTER(6, wf_sifliTest, app_get_strid(key_clk_sifliTest, "sifliTest"), \
&ops, APP_GET_THUM(tn), 0);
MODULE_INIT_DEF(wf_sifliTest_register)
MODULE_CLEANUP_DEF(NULL)
